package com.example.ex02.festival.repository;

import com.example.ex02.festival.entity.FestivalDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FestivalDetailRepository extends JpaRepository<FestivalDetailEntity, Long> {
}
